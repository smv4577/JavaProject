
public class Book {
	private String author;
	private String title;
	private String year;
	private String bookId;
	private static int counter = 1;
	private boolean isBorrowed;
		
	public Book(String bookId, String title, String author, String year) {
		this.bookId = bookId;
		this.author = author;
		this.title = title;
		this.year = year;
		counter++;
		this.counter();
	}
	
	public Book(String title, String author, String year) {
		bookId = "B" + counter;
		counter++;
		this.author = author;
		this.title = title;
		this.year = year;
	}
	
	private void counter() {
		String[] parts = bookId.split("B");
		String id = parts[1];
		int id2 = parseInt(id);
		if (id2 >= counter) {
			counter = id2 + 1;
		}
	}

	private int parseInt(String id) {
		return 0;	
	}

	public String getBookId() {
		return bookId;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getYear() {
		return year;
	}
	
	public String toString() {
        return ("Book ID: " + this.getBookId() + ", Author: " + this.getAuthor() + ", Title: " + this.getTitle() + ", Year: " + this.getYear());
   }
	
	public boolean setBorrowed() {
		return this.isBorrowed = true;
	}
    
    public boolean checkBorrowed() {
    	if (this.isBorrowed == true) {
    		return true;
    	}
    	else {
    		return false;
    	}
    }
}
